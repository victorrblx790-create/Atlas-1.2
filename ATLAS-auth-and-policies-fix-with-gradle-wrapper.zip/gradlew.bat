@echo off
setlocal
set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"
set "DIST_URL="
for /f "tokens=1,* delims==" %%A in (%PROPS%) do if "%%A"=="distributionUrl" set "DIST_URL=%%B"
set "DIST_URL=%DIST_URL:\:=:%"
set "DIST_URL=%DIST_URL:\=/%"
set "DIST_FILE=%DIST_URL:*//services.gradle.org/distributions/=%"
set "VERSION=%DIST_FILE:gradle-=%"
set "VERSION=%VERSION:-bin.zip=%"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE=%GRADLE_USER_HOME%\wrapper\dists\gradle-%VERSION%"
set "DIST=%CACHE%\gradle-%VERSION%"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  if not exist "%CACHE%\gradle-%VERSION%-bin.zip" (
    echo Downloading Gradle %VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%CACHE%\gradle-%VERSION%-bin.zip'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%CACHE%\gradle-%VERSION%-bin.zip' '%CACHE%'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
endlocal
