# ATLAS — Firebase Auth Fix

The Android build now contains the ATLAS Firebase client configuration by default, so email/password authentication does not depend on a missing Codemagic environment variable.

Firebase project: `atlas-9f28f`
Android package: `com.atlas.assistant`

Google Android sign-in still requires the Firebase/Google OAuth **Web application client ID** for Credential Manager. The source does not invent that ID. If `ATLAS_GOOGLE_SERVER_CLIENT_ID` is supplied in Codemagic, the native Google flow is used; otherwise the app reports the exact missing configuration instead of pretending login works.

No password is stored locally.

The WebView Google fallback uses Firebase redirect authentication when native Credential Manager configuration is unavailable. The Firebase Console must have Google provider enabled and the app's WebView origin authorized if Firebase reports an unauthorized-domain error.
