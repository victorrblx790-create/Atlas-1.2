# ATLAS Auth — substituição do Firebase Auth

A versão 1.2.0 remove o **Firebase Authentication** do fluxo de login do aplicativo. O login por e-mail/senha, sessão, recuperação de senha e exclusão de conta usam o servidor `atlas-auth` incluído neste projeto.

## Dono da ATLAS
A conta `victorrblx790@gmail.com` recebe automaticamente a função `admin` quando cadastrada.

## Para deixar o login online
1. Publique a pasta `atlas-auth` em um serviço Node HTTPS (o projeto já inclui `render.yaml`).
2. Configure `ADMIN_EMAIL=victorrblx790@gmail.com`.
3. Para enviar notificações para esse Gmail, configure SMTP do Gmail com uma **senha de app** em `SMTP_USER`/`SMTP_PASS`.
4. Depois de publicar, pegue a URL HTTPS do servidor e coloque em `ATLAS_AUTH_URL` no Codemagic.
5. Gere novamente o APK/AAB.

### Segurança
- Senhas usam bcrypt e nunca são enviadas ao Gmail.
- Sessões usam JWT.
- Recuperação usa token aleatório com hash e expiração.
- O Gmail recebe apenas notificações administrativas e e-mails de recuperação; nunca recebe senhas.
- Não coloque senha de app, JWT secret ou qualquer credencial SMTP no APK ou no Git.

## Google
O botão Google foi separado do Firebase. Para ativá-lo no ATLAS Auth será necessário configurar OAuth 2.0 no servidor (`GOOGLE_CLIENT_ID` + `GOOGLE_CLIENT_SECRET`) e um callback HTTPS. O login por e-mail/senha não depende disso.
