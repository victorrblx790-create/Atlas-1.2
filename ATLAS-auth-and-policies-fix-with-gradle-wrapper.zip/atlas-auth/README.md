# ATLAS Auth

Autenticação própria da ATLAS, sem Firebase Authentication.

## Recursos
- cadastro e login por e-mail/senha
- bcrypt para senhas
- JWT de sessão
- recuperação de senha por e-mail
- exclusão de conta
- SQLite persistente
- notificação de novos cadastros para `ADMIN_EMAIL`
- rate limiting e headers de segurança

## Gmail
Para enviar notificações para `victorrblx790@gmail.com`, configure SMTP do Gmail com uma **senha de app** em `SMTP_PASS`. Nunca coloque essa senha no APK ou no Git.

## Deploy
O projeto inclui `render.yaml`. Depois de publicar o serviço, defina no app `ATLAS_AUTH_CONFIG.endpoint` para a URL HTTPS do serviço.
